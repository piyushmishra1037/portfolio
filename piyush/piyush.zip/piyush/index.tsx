"use client"
/**
 * Preview/runtime entrypoint – re-exports the main Home page.
 */
import Home from "./app/page"

export default function App() {
  return <Home />
}
