import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import { Navbar } from "@/components/layout/navbar"
import { Footer } from "@/components/layout/footer"
import { ThreeBackground } from "@/components/three-background"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Piyush Mishra - Full-Stack Developer Portfolio",
  description:
    "Motivated Full-Stack Web Developer with hands-on experience in building responsive web applications using the MERN stack.",
  keywords: [
    "Piyush Mishra",
    "Full-Stack Developer",
    "Web Developer",
    "React.js",
    "Node.js",
    "MongoDB",
    "JavaScript",
    "Portfolio",
  ],
  openGraph: {
    title: "Piyush Mishra - Full-Stack Developer Portfolio",
    description:
      "Motivated Full-Stack Web Developer with hands-on experience in building responsive web applications using the MERN stack.",
    url: "https://your-portfolio-url.com", // Replace with your actual URL
    siteName: "Piyush Mishra Portfolio",
    images: [
      {
        url: "/placeholder.svg", // Replace with a proper social share image
        width: 800,
        height: 600,
        alt: "Piyush Mishra Portfolio",
      },
    ],
    locale: "en_IN",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Piyush Mishra - Full-Stack Developer Portfolio",
    description:
      "Motivated Full-Stack Web Developer with hands-on experience in building responsive web applications using the MERN stack.",
    images: ["/placeholder.svg"],
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem disableTransitionOnChange>
          <ThreeBackground />
          <Navbar />
          {children}
          <Footer />
        </ThemeProvider>
      </body>
    </html>
  )
}
